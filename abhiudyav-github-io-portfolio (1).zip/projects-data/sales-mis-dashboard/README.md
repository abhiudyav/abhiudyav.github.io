# Sales MIS Dashboard

Status: **Completed**

A single-workbook, fully formula-driven Excel MIS dashboard over 1,039
Australian retail order lines (Feb 2013 – Feb 2017). See the full case study
at [`/projects/sales-mis-dashboard.html`](../../projects/sales-mis-dashboard.html).

## Contents

- Workbook file: `Sales_MIS_Dashboard.xlsx` (add your copy here if you want
  the source file browsable from the repo — it is not duplicated in this
  folder by default to keep the repository light).
- Sheets: `README`, `DASHBOARD`, `DATA`, `CALC`, `LISTS`, `RAW_DATA`.

## Key facts (verified from the file)

- 1,039 order line items, 538 distinct customers, 3 product categories,
  2 regions (NSW, VIC), 4 customer segments, 14 salespeople.
- Calculation engine: `SUMPRODUCT` (1,044 uses) + `INDEX`/`MATCH` (81 uses
  each) + `LARGE`, `IFERROR`, `COUNTIF`/`COUNTIFS`/`COUNTBLANK`.
- No PivotTables, Slicers, VBA, or actual Conditional Formatting rules — the
  ✓/⚠ data quality indicators are `IF`-formula text, not CF rules.
- 7 filters via Data Validation dropdown lists (Year, Quarter, Month,
  Category, Region, Segment, Salesperson).
- 6 native Excel charts: 1 line, 4 bar/column, 1 pie.

## Notes

All figures in the case study (Total Sales $1,199,395, Total Profit
$561,876, Profit Margin 46.8%, etc.) are read directly from the workbook
with filters set to "All" — none are invented.
