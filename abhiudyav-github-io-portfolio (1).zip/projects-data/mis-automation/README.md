# MIS Automation (Python)

Status: **Completed — 9 of 9 build phases delivered**

A modular Python pipeline that takes a raw CSV/XLSX and produces a full MIS
Excel report: ingestion, profiling, cleaning (with a full audit trail),
transformation, KPI calculation, pivot tables with native Excel charts,
optional AI-generated insights, read-only SQL analysis, and a Power
BI-ready export — with an independent quality-control pass at the end.

See the full case study at
[`/projects/mis-automation.html`](../../projects/mis-automation.html).

## Source

The full source lives in the accompanying project archive
(`mis_automation_final.zip` as supplied) — copy the `mis_automation/`
package into this folder (or a `src/` subfolder) if you want the code
browsable directly from this repository.

## Architecture

```
INPUT → FileLoader → DataProfiler → DataCleaner → DataTransformer
      → business_meaning (role inference) → Analyzer → KPIEngine
      → PivotEngine → ChartEngine (native Excel charts)
      → AI Insight Engine (optional) → SQLEngine (optional)
      → PowerBIEngine (optional) → ExcelReportGenerator
      → QualityControl → OUTPUT
```

## Verified facts (from the code and a real run against the bundled sample data)

- 44 automated tests across `test_phase1.py`, `test_phase2.py`, `test_phase3to7.py`.
- Sample run: 510 rows, 10 → 16 columns after transformation, 9 cleaning
  actions logged, 12 pivot tables generated, 23-sheet Excel report produced.
- No `.pbix` file is ever created — Power BI Desktop/Service isn't available
  headlessly; the pipeline exports Power BI-ready CSVs + a data dictionary +
  DAX measures instead, and states this limitation explicitly in its own
  output notes.
- AI insight generation is only ever given pre-computed KPI/trend/anomaly
  figures — it never computes numbers itself.
- SQL access is read-only by default (`sql_allow_write: false`), enforced at
  the engine layer with a keyword filter as defense-in-depth.

## Environment variables

Copy `.env.example` to `.env` and set:

```
CLAUDE_API_KEY=YOUR_API_KEY
```

Never commit a real `.env` file or API key to this repository.
