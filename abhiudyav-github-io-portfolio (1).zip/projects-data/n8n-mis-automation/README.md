# AI-Powered MIS Executive Automation (n8n)

Status: **Built as a self-learning project.** The workflow export (`workflow.json`)
and screenshots are not yet in this folder; the description below comes from the
author's resume.

## Overview
Monitors Gmail for emails with Excel/CSV attachments, validates and extracts the
attachment and email text, and uses a Python/FastAPI service plus the Claude API to
decide what to do with the workbook.

## Problem
Emailed spreadsheet requests are handled by hand: open, interpret, edit, reply.

## Solution
Automate the loop with a safety valve: the AI returns a structured decision with a
confidence score; low confidence triggers a clarification email.

## Workflow
Gmail intake -> validate/extract -> FastAPI inspects workbook -> Claude API analysis
-> confidence check -> (clarification email | FastAPI Excel processing) -> completed
workbook emailed back.

## n8n Nodes
To be listed from the actual workflow export.

## AI Integration
Claude API returns JSON: decision, confidence score, task, reason, required columns,
requested operations.

## Data Processing
Python/FastAPI inspects and processes workbooks; tracks job ID, output filename, row counts.

## Output
Completed Excel workbook by email, or a clarification email.

## Technologies
n8n, Python, FastAPI, Gmail, Claude API, REST API, JSON, Excel.

## Setup / Configuration
Add once the workflow export is committed.

## Environment Variables
Use placeholders only:
```
YOUR_API_KEY
YOUR_CREDENTIAL_ID
YOUR_EMAIL
```

## Security
Strip all credentials, OAuth tokens and private URLs from `workflow.json` before committing.

## Future Improvements
Human approval before send, persistent logging, scheduled reports, database/Power BI integration.
