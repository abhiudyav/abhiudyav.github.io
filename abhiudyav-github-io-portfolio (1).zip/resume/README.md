# Resume

`Abhiudya-Verma-Resume.pdf` is the PDF version of your resume (converted from the .docx). Replace it with a fresh export whenever you update the resume.
